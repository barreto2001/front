<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Notifications\Notifiable;
use Laravel\Sanctum\HasApiTokens;

class User extends Authenticatable
{
    use HasApiTokens, HasFactory, Notifiable;

    protected $table = "users"; // Cambia el nombre de la tabla aquí

    /**
     * The attributes that are mass assignable.
     *
     * @var array<int, string>
     */
    protected $fillable = [
        'id',
        'nombres',
        'apellidos',
        'email',
        'telefono',
        'tipo_documento',
        'documento',
        'rol',
        'especializacion',
        'password',
        'remember_token'
    ];

    /**
     * The attributes that should be hidden for serialization.
     *
     * @var array<int, string>
     */
    protected $hidden = [
        'password',
        'remember_token',
    ];

    /**
     * The attributes that should be cast.
     *
     * @var array<string, string>
     */
    protected $casts = [
        'password' => 'hashed',
    ];

    public $timestamps = false;

    public function tipoDocumento()
    {
        return $this->belongsTo(TipoDocumento::class, 'id');
    }

    public function especializacion()
    {
        return $this->belongsTo(Especializacion::class, 'id');
    }

    public function historial()
    {
        return $this->belongsTo(Historial::class, 'id');
    }

    public function rol()
    {
        return $this->belongsToMany(Rol::class, 'id');
    }

    public function hasRole($rol)
    {
        return $this->rol->contains('nombre', $rol);
    }

}
