<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Historial extends Model
{
    use HasFactory;

    protected $table = 'historial';

    /**
     * The attributes that are mass assignable.
     *
     * @var array<int, string>
     */
    protected $fillable = [
        'id',
        'id_paciente',
        'id_doctor',
        'especializacion',
        'id_cita',
        'descripcion'
    ];

    public $timestamps = false;

    public function user()
    {
        return $this->belongsTo(User::class, 'id');
    }

    public function especializacion()
    {
        return $this->belongsTo(Especializacion::class, 'id');
    }

    public function cita()
    {
        return $this->belongsTo(Cita::class, 'id');
    }

    public function hasDoctor($id)
    {
        return $this->user->contains('id', $id);
    }
}
