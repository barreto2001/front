<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Cita extends Model
{
    use HasFactory;

    protected $table = 'cita';

    /**
     * The attributes that are mass assignable.
     *
     * @var array<int, string>
     */
    protected $fillable = [
        'id',
        'id_paciente',
        'id_doctor',
        'estado',
        'fecha',
        'turno',
        'descripcion',
        'especializacion'
    ];

    public $timestamps = false;

    public function user()
    {
        return $this->belongsTo(User::class, 'id');
    }

    public function especializacion()
    {
        return $this->belongsTo(Especializacion::class, 'id');
    }

    public function historial()
    {
        return $this->belongsTo(Historial::class, 'id');
    }

    public function hasDoctor($id)
    {
        return $this->user->contains('id', $id);
    }
}
