<?php

namespace App\Http\Controllers;

use App\Models\Cita;
use App\Models\Especializacion;
use App\Models\User;
use Illuminate\Http\Request;

class HomeController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('auth');
    }

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Contracts\Support\Renderable
     */
    public function index()
    {
        $citas = null;

        if(auth()->user()->rol == 1){
            $citas = Cita::where('id_paciente', auth()->user()->id)
                    ->orderBy('fecha', 'asc')
                    /* ->with(['users', 'especializacion']) */
                    ->get();
            for($i = 0; $i < count($citas); $i++){
                $citas[$i]->id_doctor = User::find($citas[$i]->id_doctor);
                $citas[$i]->especializacion = Especializacion::find($citas[$i]->especializacion);
            }
        }else{
            $citas = Cita::where('id_doctor', auth()->user()->id)
                    ->orderBy('fecha', 'asc')
                    ->get();

            for($i = 0; $i < count($citas); $i++){
                $citas[$i]->id_paciente = User::find($citas[$i]->id_paciente);
                $citas[$i]->especializacion = Especializacion::find($citas[$i]->especializacion);
            }
        }

        return view('home',['citas' => $citas]);
    }
}
