$.ajax({
    type: 'get',
    url: 'http://127.0.0.1:8000/api/tipoDocumento'


})
.done( response => {
    response.map(e =>{
        let option = '<option value="'+e.id+'">'+e.sigla+'-'+e.nombre+'</option>';
        let tipoDocumento = document.getElementById('tipo_documento');
        tipoDocumento.innerHTML+=option;
    })
})
.fail(fail => {
    alert('Ups algo salio mal.')
})
