$.ajax({
        type: 'get',
        url: 'http://127.0.0.1:8000/api/especializacion'


    })
    .done(response => {
        response.map(e => {
            let option = '<option value="' + e.id + '">' + e.nombre + '</option>';
            let especializacion = document.getElementById('especializacion');
            especializacion.innerHTML += option;
        })
    })
    .fail(fail => {
        alert('Ups algo salio mal.')
    })

document.getElementById('fecha').addEventListener('input', function (e) {
    let valor = e.target.value;
    var selectedDate = new Date(valor); // Utiliza el valor directamente

    // 0 es domingo y 6 es sábado
    if (selectedDate.getDay() === 5 || selectedDate.getDay() === 6) {
        alert('No puedes seleccionar un sábado o domingo.');
    } else {
        $.ajax({
                type: 'get',
                url: 'http://127.0.0.1:8000/api/cita/' + $("#especializacion").val() + "/" + valor,
                headers: {
                    // Incluye el token de autenticación en el encabezado
                    "Authorization": "SCY3III1SoafGlJ8x9ZNSqtd5MP9CqbAvAD8FTkzsTfNt8LGWDwUAgmpcDAP"
                }
            })
            .done(response => {
                let turnos = [1, 2, 3, 4, 5, 6];
                if (response.length > 5) {
                    // Si no hay citas disponibles, muestra un mensaje
                    document.getElementById("turno").innerHTML = '<option selected value="">No hay citas disponibles</option>';
                } else {
                    for (let i = 0; i < response.length; i++) {
                        if (turnos.indexOf(response[i].id) !== -1) {
                            let po = turnos.indexOf(response[i].id);
                            delete turnos[po];
                        }
                    }

                    var turnoSelect = document.getElementById("turno");
                    var descripcion = document.getElementById("descripcion");
                    descripcion.disabled = false;
                    turnoSelect.disabled = false;

                    // Limpia las opciones anteriores
                    turnoSelect.innerHTML = '';

                    // Agrega las opciones disponibles
                    for (let i = 0; i < turnos.length; i++) {
                        /* if (turnos[i]) {
                            turnoSelect.innerHTML += '<option value="' + turnos[i] + '" id="turno-' + turnos[i] + '">Horario ' + (turnos[i] + 8) + ':00 AM</option>';
                        } */

                        switch (turnos[i]) {
                            case 1:
                                turnoSelect.innerHTML += '<option value="' + turnos[i] + '" >Horario 9:00 AM</option>'
                                break;
                                case 2:
                                turnoSelect.innerHTML += '<option value="' + turnos[i] + '" >Horario 10:00 AM</option>'
                                break;
                                case 3:
                                turnoSelect.innerHTML += '<option value="' + turnos[i] + '" >Horario 11:00 AM</option>'
                                break;
                                case 4:
                                turnoSelect.innerHTML += '<option value="' + turnos[i] + '" >Horario 2:00 AM</option>'
                                break;
                                case 5:
                                turnoSelect.innerHTML += '<option value="' + turnos[i] + '" >Horario 3:00 AM</option>'
                                break;
                                case 6:
                                turnoSelect.innerHTML += '<option value="' + turnos[i] + '" >Horario 4:00 AM</option>'
                                break;

                            default:
                                break;
                        }
                    }
                    turnoSelect.innerHTML += '<option value="" selected>Seleccione...</option>'
                }
            })
            .fail(fail => {
                alert('Ups, algo salió mal.');
            });
    }
});


$("#especializacion").change((e) => {
    let valor = e.target.value;
    let fecha = $("#fecha");
    let turno = document.getElementById("turno");
    if (valor !== "") {
        fecha.prop("disabled", false);
    } else {
        fecha.prop("disabled", true);
        fecha.val("");
        turno.disabled = true;
        turno.innerHTML = '<option selected>Seleccione</option>';
    }
});
