$(".edit").change(e=>{
    var valorEsp = $("#especializacion").val();
    var valorFecha = $("#fecha").val();
    var valorTurno = $("#turno").val();
    $.ajax({
        type: 'get',
        url: 'http://127.0.0.1:8000/api/cita/' + valorEsp + "/" + valorFecha+"/"+valorTurno,
        headers: {
            // Incluye el token de autenticación en el encabezado
            "Authorization": "SCY3III1SoafGlJ8x9ZNSqtd5MP9CqbAvAD8FTkzsTfNt8LGWDwUAgmpcDAP"
        }
    })
    .done(response => {
        if(response.length > 0){
            alert("La cita no se encuentra disponible, por favor escoja otro horario o fecha.")
            $("#btn-submit").prop("disabled",true);
        }else{
            $("#btn-submit").prop("disabled",false);
        }
    })
    .fail(fail => {
        alert('Ups, algo salió mal.');
    });
});

document.getElementById('fecha').addEventListener('input', function (e) {
    let valor = e.target.value;
    var selectedDate = new Date(valor); // Utiliza el valor directamente

    // 0 es domingo y 6 es sábado
    if (selectedDate.getDay() === 5 || selectedDate.getDay() === 6) {
        alert('No puedes seleccionar un sábado o domingo.');
    }
});
