@include('layouts.app')
<div class="container">
    <h2 class="text-center">Editando Cita</h2>
    <form method="POST" action="{{ route('cita.store') }}">
        @csrf
        <div class="row mb-3">
            <label for="especializacion" class="col-md-4 col-form-label text-md-end">{{ __('Especialización') }}</label>

            <div class="col-md-6">
                <select id="especializacion" class="form-select @error('especializacion') is-invalid @enderror edit" aria-label="Default select example" required name="especializacion">
                    <option value="1" {{ old('especializacion',$cita->especializacion) == 1 ? 'selected' : '' }}>Odontología</option>
                    <option value="2" {{ old('especializacion',$cita->especializacion) == 2 ? 'selected' : '' }}>Medicina General</option>
                    <option value="3" {{ old('especializacion',$cita->especializacion) == 3 ? 'selected' : '' }}>Optometría</option>
                  </select>

                @error('especializacion')
                    <span class="invalid-feedback" role="alert">
                        <strong>{{ $message }}</strong>
                    </span>
                @enderror
            </div>
        </div>

        <div class="row mb-3">
            <label for="fecha" class="col-md-4 col-form-label text-md-end">{{ __('Fecha') }}</label>

            <div class="col-md-6">
                <input id="fecha" type="date" class="form-control @error('fecha') is-invalid @enderror edit" name="fecha" value="{{ old('fecha',$cita->fecha) }}" required autocomplete="fecha" >

                @error('fecha')
                    <span class="invalid-feedback" role="alert">
                        <strong>{{ $message }}</strong>
                    </span>
                @enderror
            </div>
        </div>

        <div class="row mb-3">
            <label for="turno" class="col-md-4 col-form-label text-md-end">{{ __('Turno') }}</label>

            <div class="col-md-6">
                <select id="turno" class="form-select @error('turno') is-invalid @enderror edit" aria-label="Default select example" required name="turno" >
                    <option value="1" {{ old('turno',$cita->turno) == 1 ? 'selected' : '' }}>9:00 AM</option>
                    <option value="2" {{ old('turno',$cita->turno) == 2 ? 'selected' : '' }}>10:00 AM</option>
                    <option value="3" {{ old('turno',$cita->turno) == 3 ? 'selected' : '' }}>11:00 AM</option>
                    <option value="4" {{ old('turno',$cita->turno) == 4 ? 'selected' : '' }}>2:00 PM</option>
                    <option value="5" {{ old('turno',$cita->turno) == 5 ? 'selected' : '' }}>3:00 PM</option>
                    <option value="6" {{ old('turno',$cita->turno) == 6 ? 'selected' : '' }}>4:00 PM</option>
                  </select>

                @error('turno')
                    <span class="invalid-feedback" role="alert">
                        <strong>{{ $message }}</strong>
                    </span>
                @enderror
            </div>
        </div>

        <div class="row mb-3">
            <label for="descripcion" class="col-md-4 col-form-label text-md-end">{{ __('Motivo') }}</label>

            <div class="col-md-6">
                <textarea name="descripcion" id="descripcion" class="form-control @error('descripcion') is-invalid @enderror" cols="30" rows="10" required >
                    {{ old('descripcion',$cita->descripcion) }}
                </textarea>

                @error('descripcion')
                    <span class="invalid-feedback" role="alert">
                        <strong>{{ $message }}</strong>
                    </span>
                @enderror
            </div>
        </div>

        <div class="row mb-0">
            <div class="col-md-6 offset-md-4">
                <button type="submit" class="btn btn-primary" disabled id="btn-submit">
                    {{ __('Actualizar lista') }}
                </button>

            </div>
        </div>
    </form>

    <a href="{{ route('home') }}">
        <button class="btn btn-danger">Cancelar y volver</button>
    </a>
</div>
<script src="{{ asset('js/jquery-3.7.1.min.js') }}"></script>
<script src="{{ asset('js/citaEdit.js') }}"></script>
