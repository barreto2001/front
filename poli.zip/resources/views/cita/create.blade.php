@include('layouts.app')

<h3 class="text-center">Nueva Cita</h3>
<div class="container">
    <form method="POST" action="{{ route('cita.store') }}">
        @csrf
        <div class="row mb-3">
            <label for="especializacion" class="col-md-4 col-form-label text-md-end">{{ __('Especialización') }}</label>

            <div class="col-md-6">
                <select id="especializacion" class="form-select @error('especializacion') is-invalid @enderror" aria-label="Default select example" required name="especializacion">
                    <option selected value="">Seleccione</option>
                  </select>

                @error('especializacion')
                    <span class="invalid-feedback" role="alert">
                        <strong>{{ $message }}</strong>
                    </span>
                @enderror
            </div>
        </div>

        <div class="row mb-3">
            <label for="fecha" class="col-md-4 col-form-label text-md-end">{{ __('Fecha') }}</label>

            <div class="col-md-6">
                <input id="fecha" type="date" class="form-control @error('fecha') is-invalid @enderror" name="fecha" value="{{ old('fecha') }}" required autocomplete="fecha" disabled>

                @error('fecha')
                    <span class="invalid-feedback" role="alert">
                        <strong>{{ $message }}</strong>
                    </span>
                @enderror
            </div>
        </div>

        <div class="row mb-3">
            <label for="turno" class="col-md-4 col-form-label text-md-end">{{ __('Turno') }}</label>

            <div class="col-md-6">
                <select id="turno" class="form-select @error('turno') is-invalid @enderror" aria-label="Default select example" required name="turno" disabled>
                    <option selected>Seleccione</option>
                    <option value="1" id="turno-1">9:00 AM</option>
                    <option value="2" id="turno-2">10:00 AM</option>
                  </select>

                @error('turno')
                    <span class="invalid-feedback" role="alert">
                        <strong>{{ $message }}</strong>
                    </span>
                @enderror
            </div>
        </div>

        <div class="row mb-3">
            <label for="descripcion" class="col-md-4 col-form-label text-md-end">{{ __('Motivo') }}</label>

            <div class="col-md-6">
                <textarea name="descripcion" id="descripcion" class="form-control @error('descripcion') is-invalid @enderror" cols="30" rows="10" required disabled>
                    {{ old('descripcion') }}
                </textarea>

                @error('descripcion')
                    <span class="invalid-feedback" role="alert">
                        <strong>{{ $message }}</strong>
                    </span>
                @enderror
            </div>
        </div>

        <div class="row mb-0">
            <div class="col-md-6 offset-md-4">
                <button type="submit" class="btn btn-primary">
                    {{ __('Crear Cita') }}
                </button>
            </div>
        </div>
    </form>
</div>
<script src="{{ asset('js/jquery-3.7.1.min.js') }}"></script>
<script src="{{ asset('js/citaCreate.js') }}"></script>
