@include('layouts.app')

<h3 class="text-center">Historial de la cita</h3>
<div class="container">
    <div class="mt-5 mb-5 row">
        <div class="col-md-3">
            <strong>Paciente: </strong>
            {{ $cita->id_paciente->nombres." ".$cita->id_paciente->apellidos }}
        </div>
        <div class="col-md-3">
            <strong>Fecha: </strong>
            {{ $cita->fecha }}
        </div>
        <div class="col-md-3">
            <strong>Hora: </strong>
            {{ $cita->turno }}
        </div>
        <div class="col-md-3">
            <strong>Especialización: </strong>
            {{ $cita->especializacion->nombre }}
        </div>
    </div>

    <form method="POST" action="{{ route('historial.store') }}">
        @csrf
        <input type="hidden" value="{{ $cita->id_doctor }}" name="id_doctor">
        <input type="hidden" value="{{ $cita->id_paciente->id }}" name="id_paciente">
        <input type="hidden" value="{{ $cita->especializacion->id }}" name="especializacion">
        <input type="hidden" value="{{ $cita->id}}" name="id_cita">
        <div class="row mb-3">
            <label for="descripcion" class="col-md-4 col-form-label text-md-end">{{ __('Descripción') }}</label>

            <div class="col-md-6">
                <textarea name="descripcion" id="descripcion" class="form-control @error('descripcion') is-invalid @enderror" cols="30" rows="10" required >
                    {{ old('descripcion') }}
                </textarea>

                @error('descripcion')
                    <span class="invalid-feedback" role="alert">
                        <strong>{{ $message }}</strong>
                    </span>
                @enderror
            </div>
        </div>
        <button type="submit" class="btn btn-primary">Terminar Cita</button>
    </form>
</div>
