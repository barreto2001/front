@include('layouts.app')

<h3 style="text-align: center;">¡Bienvenido {{ auth()->user()->nombres }}!</h3>



<div class="container">
    <a href="{{ route('cita.create') }}">
        <button class="btn btn-primary mt-5 mb-5">Nueva cita</button>
    </a>

    <table class="table">
        @if (auth()->user()->rol == 1)
            <thead>
                <tr>
                    <th scope="col">Fecha</th>
                    <th scope="col">Doctor</th>
                    <th scope="col">Especialización</th>
                    <th scope="col">Hora</th>
                    <th scope="col">Estado</th>
                    <th scope="col">Opciones</th>
                </tr>
            </thead>
            <tbody>
                @foreach ($citas as $cita)
                    <tr>
                        <th scope="row">{{ $cita->fecha }}</th>
                        <td>{{ $cita->id_doctor->nombres }} {{ $cita->id_doctor->apellidos }}</td>
                        <td>{{ $cita->especializacion->nombre }}</td>
                        <td>
                            @switch($cita->turno)
                                @case('1')
                                    9:00 AM
                                @break

                                @case('2')
                                    10:00 AM
                                @break

                                @case('3')
                                    11:00 AM
                                @break

                                @case('4')
                                    2:00 AM
                                @break

                                @case('5')
                                    3:00 AM
                                @break

                                @case('6')
                                    4:00 PM
                                @break

                                @default
                            @endswitch
                        </td>
                        <td>
                            @if ($cita->estado == 'A')
                                Activa
                            @endif
                            @if ($cita->estado == 'C')
                                Cancelada
                            @endif
                        </td>
                        <td>
                            @if ($cita->estado == 'A')
                                <form action="{{ route('cita.destroy', ['id' => $cita->id]) }}" method="POST">
                                    @csrf
                                    @method('DELETE')
                                    <button type="submit" class="btn btn-danger"
                                        onclick="return confirm('¿Estás seguro de que deseas eliminar esta cita?')">Cancelar</button>
                                </form>
                                <a href="{{ route('cita.edit', $cita->id) }}">
                                    <button class="btn btn-warning">Cambiar</button>
                                </a>
                            @endif
                        </td>
                    </tr>
                @endforeach
            </tbody>
        @endif

        @if (auth()->user()->rol == 2)
            <thead>
                <tr>
                    <th scope="col">Fecha</th>
                    <th scope="col">Paciente</th>
                    <th scope="col">Hora</th>
                    <th scope="col">Estado</th>
                    <th scope="col">Opciones</th>
                </tr>
            </thead>
            <tbody>
                @foreach ($citas as $cita)
                    <tr>
                        <th scope="row">{{ $cita->fecha }}</th>
                        <td>{{ $cita->id_paciente->nombres }} {{ $cita->id_paciente->apellidos }}</td>
                        <td>
                            @switch($cita->turno)
                                @case('1')
                                    9:00 AM
                                @break

                                @case('2')
                                    10:00 AM
                                @break

                                @case('3')
                                    11:00 AM
                                @break

                                @case('4')
                                    2:00 AM
                                @break

                                @case('5')
                                    3:00 AM
                                @break

                                @case('6')
                                    4:00 PM
                                @break

                                @default
                            @endswitch
                        </td>
                        <td>
                            @if ($cita->estado == 'A')
                                Activa
                            @endif
                            @if ($cita->estado == 'C')
                                Cancelada
                            @endif
                            @if ($cita->estado == 'T')
                                Terminada
                            @endif
                        </td>
                        <td>
                            @if ($cita->estado == 'A')
                                <form action="{{ route('cita.destroy', ['id' => $cita->id]) }}" method="POST">
                                    @csrf
                                    @method('DELETE')
                                    <button type="submit" class="btn btn-danger"
                                        onclick="return confirm('¿Estás seguro de que deseas eliminar esta cita?')">Cancelar</button>
                                </form>
                                <a href="{{ route('cita.show', $cita->id) }}">
                                    <button class="btn btn-success">Iniciar Cita</button>
                                </a>
                            @endif
                        </td>
                    </tr>
                @endforeach
            </tbody>
        @endif

    </table>
</div>
