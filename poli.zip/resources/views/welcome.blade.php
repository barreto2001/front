@include('layouts.app')
<section class="hero">
    <h2>Bienvenido a nuestro hospital</h2>
    <p>Somos un centro médico comprometido con tu bienestar. Contamos con un equipo de profesionales de la salud altamente calificados y tecnología de vanguardia.</p>
    <a href="#contacto" class="btn">Contáctanos</a>
</section>

<section class="services">
    <h2>Nuestros Servicios</h2>
    <ul>
        <li>Atención médica especializada</li>
        <li>Cirugía de vanguardia</li>
        <li>Consultas en línea</li>
        <li>Unidad de cuidados intensivos</li>
    </ul>
</section>

<section id="contacto" class="contact">
    <h2>Contacto</h2>
    <p>Estamos aquí para ayudarte. Ponte en contacto con nosotros para programar una cita o hacer cualquier pregunta que tengas.</p>
    <address>
        <p>Dirección: Calle Principal, Ciudad</p>
        <p>Teléfono: (123) 456-7890</p>
        <p>Email: info@hospital-sanjose.com</p>
    </address>
</section>

<footer>
    <p>&copy; 2023 Hospital San José. Todos los derechos reservados.</p>
</footer>

<style>
    /* styles.css */
body {
    font-family: Arial, sans-serif;
    margin: 0;
    padding: 0;
}


.hero {
    background-image: url('hospital-image.jpg');
    background-size: cover;
    color: #333;
    padding: 40px;
    text-align: center;
}

.btn {
    background-color: #0055A4;
    color: #fff;
    padding: 10px 20px;
    text-decoration: none;
    border-radius: 5px;
}

.btn:hover {
    background-color: #003D78;
}

.services {
    background-color: #f4f4f4;
    padding: 20px;
}

.contact {
    padding: 40px;
    text-align: center;
}

footer {
    background-color: #333;
    color: #fff;
    text-align: center;
    padding: 10px;
}

</style>

