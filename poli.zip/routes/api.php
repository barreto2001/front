<?php

use App\Http\Controllers\CitaController;
use App\Http\Controllers\EspecializacionController;
use App\Http\Controllers\TipoDocumentoController;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "api" middleware group. Make something great!
|
*/

Route::middleware('auth:sanctum')->get('/user', function (Request $request) {
    return $request->user();
});

Route::prefix('tipoDocumento')->group(function () {
    Route::get('/', [TipoDocumentoController::class, 'index']);
    Route::get('/{id}', [TipoDocumentoController::class, 'show']);
    Route::post('/', [TipoDocumentoController::class, 'store']);
    Route::put('/{id}', [TipoDocumentoController::class, 'update']);
    Route::delete('/{id}', [TipoDocumentoController::class, 'destroy']);
})->middleware('guest');

Route::prefix('especializacion')->group(function () {
    Route::get('/', [EspecializacionController::class, 'index']);
    Route::get('/{id}', [EspecializacionController::class, 'show']);
    Route::post('/', [EspecializacionController::class, 'store']);
    Route::put('/{id}', [EspecializacionController::class, 'update']);
    Route::delete('/{id}', [EspecializacionController::class, 'destroy']);
})->middleware('guest');

Route::prefix('cita')->group(function () {
    Route::get('/{especializacion}/{fecha}', [CitaController::class, 'getCitas']);
    Route::get('/{especializacion}/{fecha}/{turno}', [CitaController::class, 'getCitaDisponibilidad']);
})->middleware('guest');
