<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<h3 class="text-center">Historial de la cita</h3>
<div class="container">
    <div class="mt-5 mb-5 row">
        <div class="col-md-3">
            <strong>Paciente: </strong>
            <?php echo e($cita->id_paciente->nombres." ".$cita->id_paciente->apellidos); ?>

        </div>
        <div class="col-md-3">
            <strong>Fecha: </strong>
            <?php echo e($cita->fecha); ?>

        </div>
        <div class="col-md-3">
            <strong>Hora: </strong>
            <?php echo e($cita->turno); ?>

        </div>
        <div class="col-md-3">
            <strong>Especialización: </strong>
            <?php echo e($cita->especializacion->nombre); ?>

        </div>
    </div>

    <form method="POST" action="<?php echo e(route('historial.store')); ?>">
        <?php echo csrf_field(); ?>
        <input type="hidden" value="<?php echo e($cita->id_doctor); ?>" name="id_doctor">
        <input type="hidden" value="<?php echo e($cita->id_paciente->id); ?>" name="id_paciente">
        <input type="hidden" value="<?php echo e($cita->especializacion->id); ?>" name="especializacion">
        <input type="hidden" value="<?php echo e($cita->id); ?>" name="id_cita">
        <div class="row mb-3">
            <label for="descripcion" class="col-md-4 col-form-label text-md-end"><?php echo e(__('Descripción')); ?></label>

            <div class="col-md-6">
                <textarea name="descripcion" id="descripcion" class="form-control <?php $__errorArgs = ['descripcion'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" cols="30" rows="10" required >
                    <?php echo e(old('descripcion')); ?>

                </textarea>

                <?php $__errorArgs = ['descripcion'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class="invalid-feedback" role="alert">
                        <strong><?php echo e($message); ?></strong>
                    </span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
        </div>
        <button type="submit" class="btn btn-primary">Terminar Cita</button>
    </form>
</div>
<?php /**PATH C:\laragon\www\poli\resources\views/cita/show.blade.php ENDPATH**/ ?>