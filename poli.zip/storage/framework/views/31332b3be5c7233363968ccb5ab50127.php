<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<h3 style="text-align: center;">¡Bienvenido <?php echo e(auth()->user()->nombres); ?>!</h3>



<div class="container">
    <a href="<?php echo e(route('cita.create')); ?>">
        <button class="btn btn-primary mt-5 mb-5">Nueva cita</button>
    </a>

    <table class="table">
        <?php if(auth()->user()->rol == 1): ?>
            <thead>
                <tr>
                    <th scope="col">Fecha</th>
                    <th scope="col">Doctor</th>
                    <th scope="col">Especialización</th>
                    <th scope="col">Hora</th>
                    <th scope="col">Estado</th>
                    <th scope="col">Opciones</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $citas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cita): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <th scope="row"><?php echo e($cita->fecha); ?></th>
                        <td><?php echo e($cita->id_doctor->nombres); ?> <?php echo e($cita->id_doctor->apellidos); ?></td>
                        <td><?php echo e($cita->especializacion->nombre); ?></td>
                        <td>
                            <?php switch($cita->turno):
                                case ('1'): ?>
                                    9:00 AM
                                <?php break; ?>

                                <?php case ('2'): ?>
                                    10:00 AM
                                <?php break; ?>

                                <?php case ('3'): ?>
                                    11:00 AM
                                <?php break; ?>

                                <?php case ('4'): ?>
                                    2:00 AM
                                <?php break; ?>

                                <?php case ('5'): ?>
                                    3:00 AM
                                <?php break; ?>

                                <?php case ('6'): ?>
                                    4:00 PM
                                <?php break; ?>

                                <?php default: ?>
                            <?php endswitch; ?>
                        </td>
                        <td>
                            <?php if($cita->estado == 'A'): ?>
                                Activa
                            <?php endif; ?>
                            <?php if($cita->estado == 'C'): ?>
                                Cancelada
                            <?php endif; ?>
                        </td>
                        <td>
                            <?php if($cita->estado == 'A'): ?>
                                <form action="<?php echo e(route('cita.destroy', ['id' => $cita->id])); ?>" method="POST">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>
                                    <button type="submit" class="btn btn-danger"
                                        onclick="return confirm('¿Estás seguro de que deseas eliminar esta cita?')">Cancelar</button>
                                </form>
                                <a href="<?php echo e(route('cita.edit', $cita->id)); ?>">
                                    <button class="btn btn-warning">Cambiar</button>
                                </a>
                            <?php endif; ?>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        <?php endif; ?>

        <?php if(auth()->user()->rol == 2): ?>
            <thead>
                <tr>
                    <th scope="col">Fecha</th>
                    <th scope="col">Paciente</th>
                    <th scope="col">Hora</th>
                    <th scope="col">Estado</th>
                    <th scope="col">Opciones</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $citas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cita): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <th scope="row"><?php echo e($cita->fecha); ?></th>
                        <td><?php echo e($cita->id_paciente->nombres); ?> <?php echo e($cita->id_paciente->apellidos); ?></td>
                        <td>
                            <?php switch($cita->turno):
                                case ('1'): ?>
                                    9:00 AM
                                <?php break; ?>

                                <?php case ('2'): ?>
                                    10:00 AM
                                <?php break; ?>

                                <?php case ('3'): ?>
                                    11:00 AM
                                <?php break; ?>

                                <?php case ('4'): ?>
                                    2:00 AM
                                <?php break; ?>

                                <?php case ('5'): ?>
                                    3:00 AM
                                <?php break; ?>

                                <?php case ('6'): ?>
                                    4:00 PM
                                <?php break; ?>

                                <?php default: ?>
                            <?php endswitch; ?>
                        </td>
                        <td>
                            <?php if($cita->estado == 'A'): ?>
                                Activa
                            <?php endif; ?>
                            <?php if($cita->estado == 'C'): ?>
                                Cancelada
                            <?php endif; ?>
                            <?php if($cita->estado == 'T'): ?>
                                Terminada
                            <?php endif; ?>
                        </td>
                        <td>
                            <?php if($cita->estado == 'A'): ?>
                                <form action="<?php echo e(route('cita.destroy', ['id' => $cita->id])); ?>" method="POST">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>
                                    <button type="submit" class="btn btn-danger"
                                        onclick="return confirm('¿Estás seguro de que deseas eliminar esta cita?')">Cancelar</button>
                                </form>
                                <a href="<?php echo e(route('cita.show', $cita->id)); ?>">
                                    <button class="btn btn-success">Iniciar Cita</button>
                                </a>
                            <?php endif; ?>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        <?php endif; ?>

    </table>
</div>
<?php /**PATH C:\laragon\www\poli\resources\views/home.blade.php ENDPATH**/ ?>