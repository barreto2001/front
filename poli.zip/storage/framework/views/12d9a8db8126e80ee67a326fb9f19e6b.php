<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div class="container">
    <h2 class="text-center">Editando Cita</h2>
    <form method="POST" action="<?php echo e(route('cita.store')); ?>">
        <?php echo csrf_field(); ?>
        <div class="row mb-3">
            <label for="especializacion" class="col-md-4 col-form-label text-md-end"><?php echo e(__('Especialización')); ?></label>

            <div class="col-md-6">
                <select id="especializacion" class="form-select <?php $__errorArgs = ['especializacion'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> edit" aria-label="Default select example" required name="especializacion">
                    <option value="1" <?php echo e(old('especializacion',$cita->especializacion) == 1 ? 'selected' : ''); ?>>Odontología</option>
                    <option value="2" <?php echo e(old('especializacion',$cita->especializacion) == 2 ? 'selected' : ''); ?>>Medicina General</option>
                    <option value="3" <?php echo e(old('especializacion',$cita->especializacion) == 3 ? 'selected' : ''); ?>>Optometría</option>
                  </select>

                <?php $__errorArgs = ['especializacion'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class="invalid-feedback" role="alert">
                        <strong><?php echo e($message); ?></strong>
                    </span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
        </div>

        <div class="row mb-3">
            <label for="fecha" class="col-md-4 col-form-label text-md-end"><?php echo e(__('Fecha')); ?></label>

            <div class="col-md-6">
                <input id="fecha" type="date" class="form-control <?php $__errorArgs = ['fecha'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> edit" name="fecha" value="<?php echo e(old('fecha',$cita->fecha)); ?>" required autocomplete="fecha" >

                <?php $__errorArgs = ['fecha'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class="invalid-feedback" role="alert">
                        <strong><?php echo e($message); ?></strong>
                    </span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
        </div>

        <div class="row mb-3">
            <label for="turno" class="col-md-4 col-form-label text-md-end"><?php echo e(__('Turno')); ?></label>

            <div class="col-md-6">
                <select id="turno" class="form-select <?php $__errorArgs = ['turno'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> edit" aria-label="Default select example" required name="turno" >
                    <option value="1" <?php echo e(old('turno',$cita->turno) == 1 ? 'selected' : ''); ?>>9:00 AM</option>
                    <option value="2" <?php echo e(old('turno',$cita->turno) == 2 ? 'selected' : ''); ?>>10:00 AM</option>
                    <option value="3" <?php echo e(old('turno',$cita->turno) == 3 ? 'selected' : ''); ?>>11:00 AM</option>
                    <option value="4" <?php echo e(old('turno',$cita->turno) == 4 ? 'selected' : ''); ?>>2:00 PM</option>
                    <option value="5" <?php echo e(old('turno',$cita->turno) == 5 ? 'selected' : ''); ?>>3:00 PM</option>
                    <option value="6" <?php echo e(old('turno',$cita->turno) == 6 ? 'selected' : ''); ?>>4:00 PM</option>
                  </select>

                <?php $__errorArgs = ['turno'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class="invalid-feedback" role="alert">
                        <strong><?php echo e($message); ?></strong>
                    </span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
        </div>

        <div class="row mb-3">
            <label for="descripcion" class="col-md-4 col-form-label text-md-end"><?php echo e(__('Motivo')); ?></label>

            <div class="col-md-6">
                <textarea name="descripcion" id="descripcion" class="form-control <?php $__errorArgs = ['descripcion'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" cols="30" rows="10" required >
                    <?php echo e(old('descripcion',$cita->descripcion)); ?>

                </textarea>

                <?php $__errorArgs = ['descripcion'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class="invalid-feedback" role="alert">
                        <strong><?php echo e($message); ?></strong>
                    </span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
        </div>

        <div class="row mb-0">
            <div class="col-md-6 offset-md-4">
                <button type="submit" class="btn btn-primary" disabled id="btn-submit">
                    <?php echo e(__('Crear Cita')); ?>

                </button>

            </div>
        </div>
    </form>

    <a href="<?php echo e(route('home')); ?>">
        <button class="btn btn-danger">Cancelar y volver</button>
    </a>
</div>
<script src="<?php echo e(asset('js/jquery-3.7.1.min.js')); ?>"></script>
<script src="<?php echo e(asset('js/citaEdit.js')); ?>"></script>
<?php /**PATH C:\laragon\www\poli\resources\views/cita/edit.blade.php ENDPATH**/ ?>